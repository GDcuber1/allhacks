<p align="center">
        <img src="https://raw.githubusercontent.com/DeadTheAmazing/TestFuck-Interpreter/e4348a665b9efc3d4380371e808f7ce58940f907/testfuck.svg?sanitize=true"
        height="200">
</p>
<p align=center><b>Interpreter and Translator for TestOut LabSims</b></p>
<hr>
<h2> How To </h2>
<p><a href="https://github.com/DeadTheAmazing/TestFuck-Interpreter/blob/main/bookmarks.txt" alt="funny">Open me in new tab and bookmark both lines of code</a><br>
<br>To use the "get answers" code, complete the test and then open the bookmark, copy the array that is generated.<br>
<br>To use the "do answers" reopen the test to retry it then open the bookmark, paste the array.<br>
<br>You have cheated on your testout!
<hr>
<h2 align="center"> Contributors </h2>
<h3 align="center"> Devs </h3>
<p align="center">ILikeBreadYum</p>
<h3 align="center"> Managers </h3>
<p align="center">DeadTheAmazing//Cysiulek</p>

