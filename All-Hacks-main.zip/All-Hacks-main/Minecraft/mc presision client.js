 this.document.location = "https://playstation452.github.io/precision-client-1.5/" 
