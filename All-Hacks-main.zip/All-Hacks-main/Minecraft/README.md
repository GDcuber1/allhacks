# you can paste this shit anywhere in the dev console
