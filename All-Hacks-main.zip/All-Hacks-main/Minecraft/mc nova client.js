 this.document.location = "https://playstation452.github.io/nova-client-1.5/"
