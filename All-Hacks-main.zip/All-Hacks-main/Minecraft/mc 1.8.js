 this.document.location = "https://playstation452.github.io/eagler-1.8/"
