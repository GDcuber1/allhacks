# Pirate's Voyage Cheats

## [Max Levels](maxLevels.js)
Maxes out all islands and your boat

## [Set Doubloons](setDoubloons.js)
Sets Doubloons

## [Start Heist](startHeist.js)
Starts a heist on someone

## [Swap Doubloons](swapDoubloons.js)
Swaps Doubloons with someone

## [Take Doubloons](takeDoubloons.js)
Takes Doubloons from someone