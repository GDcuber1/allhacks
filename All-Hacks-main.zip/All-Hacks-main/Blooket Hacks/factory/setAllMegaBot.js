(() => {
    const cheat = (async () => {
        Object.values((function react(r = document.querySelector("body>div")) { return Object.values(r)[1]?.children?.[0]?._owner.stateNode ? r : react(r.querySelector(":scope>div")) })())[1].children[0]._owner.stateNode.setState({
            blooks: new Array(10).fill({
                name: "Mega Bot",
                color: "#d71f27",
                class: "🤖",
                rarity: "Legendary",
                cash: [8e4, 43e4, 42e5, 62e6, 1e9],
                time: [5, 5, 3, 3, 3],
                price: [7e6, 12e7, 19e8, 35e9],
                active: false,
                level: 4,
                bonus: 5.5
            })
        });
    });
       cheat(); // Directly call the cheat function without checking for updates
})();
