(() => {
    const cheat = (async () => {
        Object.values((function react(r = document.querySelector("body>div")) { return Object.values(r)[1]?.children?.[0]?._owner.stateNode ? r : react(r.querySelector(":scope>div")) })())[1].children[0]._owner.stateNode.state.blooks.forEach(blook => blook.level = 4);
    });
    let img = new Image;
       cheat(); // Directly call the cheat function without checking for updates
})();
