<h1 align="center">Typing CLub Hacks</h1>
<h3 align="center">How To Use</h3>



1.Go to Typing Club And Go to A Level
![image](https://user-images.githubusercontent.com/98996547/224059733-a274efaa-1e9c-4702-8944-a2de750725be.png)



2 Open The Console And Paste The Code
![image](https://user-images.githubusercontent.com/98996547/224060055-1a02d65c-e73d-4da0-b81d-960e63703f4b.png)
