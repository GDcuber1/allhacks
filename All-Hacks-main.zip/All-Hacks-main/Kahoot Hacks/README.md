# kahoot-hacks

1. Go To Kahoot And GO TO A Game
![image](https://user-images.githubusercontent.com/98996547/224109457-9480ac8e-f1dd-42eb-9d6d-df801ac8d102.png)




2. Go To The Console And Paste The Code
![image](https://user-images.githubusercontent.com/98996547/224110086-354c5f34-20b5-483f-872e-2b7b23fe0dc1.png)

