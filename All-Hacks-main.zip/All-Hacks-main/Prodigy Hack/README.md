<h1 align="center">Prodigy Hack</h1>
<h1 align="center">How To Use</h1>


1. Go To Prodigy
![image](https://user-images.githubusercontent.com/98996547/224074243-5e04832b-6472-4ac0-8faa-5b81ecd3a382.png)




2. Open Console And Paste The Code
![image](https://user-images.githubusercontent.com/98996547/224075120-bcb15bab-2de4-4d41-8016-dbafd4b59c54.png)
