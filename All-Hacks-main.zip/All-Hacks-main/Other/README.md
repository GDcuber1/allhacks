# How To Use

1. Go to Any Site
![image](https://user-images.githubusercontent.com/98996547/227235035-4c010799-81ef-4aec-a7ac-7def38224871.png)




2.Open Console And Paste Code
![image](https://user-images.githubusercontent.com/98996547/227235064-01324137-ac77-4213-aa6e-a9c90bd6d9ff.png)



