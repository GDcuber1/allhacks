# I Ready Hacks


1. Go To Iready 
![image](https://user-images.githubusercontent.com/98996547/224452902-32d31d82-ede8-479e-9d0c-8640e64a1a5e.png)



2 Go To The Console And Paste The Code
![image](https://user-images.githubusercontent.com/98996547/224453022-0b0f6202-7ec6-40c4-99f0-12afa1af22fa.png)
