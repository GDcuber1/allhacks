# All-Hacks
## i will not be updating this as much i have too much pressure on me right now i have a 45 in one of my classes. i might come back after i bring the grade up. i am sorry for not updating the blooket hacks all the way.

most of these uses browser dev console

for the idiots this is not deployable you need to go in the files and copy the code

report a bug  [here](https://github.com/playstation452/All-Hacks/milestone/1)

suggest a hack  [here](https://github.com/playstation452/All-Hacks/milestone/2)

# credits

05konz for blooket hacks

haha-noob for iready hacks

## advertisement

my discord is playstation451#9730 dm me if you want your ad here

go look at my minecraft 1.12.2 anarchy hack client  [here](https://github.com/wdnc-mc-client/WDNC-Client)

## Star History

<a href="https://star-history.com/#playstation452/All-Hacks&Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=playstation452/All-Hacks&type=Date&theme=dark" />
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=playstation452/All-Hacks&type=Date" />
    <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=playstation452/All-Hacks&type=Date" />
  </picture>
</a>



