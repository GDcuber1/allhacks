run klib its in the files

must have python installed
