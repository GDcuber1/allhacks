<h1 align="center">GimKit Hack</h1>
Join My Dicord discord.gg/pJt627Be

<h1 align="center">How to Use</h1>

1. go to gimkit
![image](https://user-images.githubusercontent.com/98996547/224056903-45b17bfe-1a46-4e73-9da7-114ab39fcab5.png)



2. Go to the console
![image](https://user-images.githubusercontent.com/98996547/224057118-605d0c54-7831-463c-a05e-82258413b06e.png)



3. Paste Code and You Are Done
![image](https://user-images.githubusercontent.com/98996547/224057671-fd0fda67-be64-4867-adfa-cf3d7cbcb802.png)
